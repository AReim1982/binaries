#!/bin/sh

PREFIX=${DEVKITPPC}/bin/powerpc-eabi-
export PATH=$PATH:/opt/devkitpro/3rd/wii/bin
export CC=${PREFIX}gcc
export CXX=${PREFIX}g++
export AS=${PREFIX}gcc
export LD=${PREFIX}gcc
export AR=${PREFIX}ar
export RANLIB=${PREFIX}ranlib
export STRIP=${PREFIX}strip
export OBJCOPY=${PREFIX}objcopy
export MACHDEP="-I/opt/devkitpro/libogc/include  -I/opt/devkitpro/3rd/wii/include -L/opt/devkitpro/libogc/lib/wii/ -L/opt/devkitpro/3rd/wii/lib -g -O2 -Wall -DGEKKO -mcpu=750 -meabi -mhard-float -ffunction-sections -fdata-sections -fmodulo-sched"
export CFLAGS="${MACHDEP}"
export CXXFLAGS="${CFLAGS}"
export LDFLAGS="${MACHDEP}"

echo "./configure --host=ppc --disable-shared --prefix=${DEVKITPRO}/3rd/wii"
