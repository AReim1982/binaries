/* Generated automatically. */
static const char configuration_arguments[] = "../../gcc-6.2.0/configure --enable-languages=c,c++,objc --enable-lto --with-cpu=750 --disable-nls --disable-shared --enable-threads --disable-multilib --disable-win32-registry --disable-libstdcxx-pch --disable-libstdcxx-verbose --enable-cxx-flags='-ffunction-sections -fdata-sections' --target=powerpc-eabi --with-newlib --with-headers=../../newlib-2.0.0/newlib/libc/include --prefix=/opt/devkitpro/devkitPPC --disable-dependency-tracking --with-bugurl=http://wiki.devkitpro.org/index.php/Bug_Reports --with-pkgversion='devkitPPC release 28'";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "750" } };
