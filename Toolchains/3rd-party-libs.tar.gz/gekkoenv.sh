#!/bin/sh

export DEVKITPRO=/opt/devkitpro
export DEVKITPPC=${DEVKITPRO}/devkitPPC

PREFIX=${DEVKITPPC}/bin/powerpc-eabi-
export PATH=$PATH:${DEVKITPRO}/3rd/wii/bin:${DEVKITPPC}/bin
export CC=${PREFIX}gcc
export CXX=${PREFIX}g++
export AS=${PREFIX}gcc
export LD=${PREFIX}gcc
export AR=${PREFIX}ar
export RANLIB=${PREFIX}ranlib
export STRIP=${PREFIX}strip
export OBJCOPY=${PREFIX}objcopy
export MACHDEP="-I${DEVKITPRO}/libogc/include  -I${DEVKITPRO}/3rd/wii/include -L${DEVKITPRO}/libogc/lib/wii/ -L${DEVKITPRO}/3rd/wii/lib -g -O2 -Wall -DGEKKO -mcpu=750 -meabi -mhard-float -ffunction-sections -fdata-sections -fmodulo-sched"
export CFLAGS="${MACHDEP}"
export CXXFLAGS="${CFLAGS}"
export LDFLAGS="${MACHDEP}"
export SEPARATOR=:
export PKG_CONFIG_LIBDIR="/opt/devkitpro/3rd/wii/lib/pkgconfig"

echo "./configure --host=wii"
